package com.stupidsavacan.clocky;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.RemoteViews;

final class ClockWidgetRenderer {
    private static final int[] TIME_IDS = {R.id.time_sans, R.id.time_round, R.id.time_serif, R.id.time_cond, R.id.time_mono};
    private static final int[] DATE_IDS = {R.id.date_sans, R.id.date_round, R.id.date_serif, R.id.date_cond, R.id.date_mono};

    private ClockWidgetRenderer() {}

    static void render(Context c, AppWidgetManager mgr, int id) {
        Bundle o = mgr.getAppWidgetOptions(id);
        int h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        boolean compact = h > 0 && h < 180;

        int bg = WidgetPrefs.i(c,id,"bg",0);
        int layout = bg == 1 ? R.layout.widget_dark : (bg == 2 ? R.layout.widget_light : R.layout.widget_transparent);
        RemoteViews rv = new RemoteViews(c.getPackageName(), layout);

        int tf = clamp(WidgetPrefs.i(c,id,"timeFont",0),0,4);
        int df = clamp(WidgetPrefs.i(c,id,"dateFont",0),0,4);
        boolean showDate = WidgetPrefs.b(c,id,"showDate",true);
        int timeSize = WidgetPrefs.i(c,id,"timeSize",120);
        int dateSize = WidgetPrefs.i(c,id,"dateSize",18);
        if (compact) { timeSize = Math.min(timeSize, 86); dateSize = Math.min(dateSize, 16); }

        String defaultTime = bg==2 ? "#FF111111" : "#FFFFFFFF";
        String defaultDate = bg==2 ? "#CC111111" : "#CCFFFFFF";
        int timeColor = parseColor(WidgetPrefs.s(c,id,"timeColor",defaultTime), bg==2?0xff111111:Color.WHITE);
        int dateColor = parseColor(WidgetPrefs.s(c,id,"dateColor",defaultDate), bg==2?0xcc111111:0xCCFFFFFF);
        int gravity = gravity(WidgetPrefs.i(c,id,"align",1));
        int hour = WidgetPrefs.i(c,id,"hourMode",0);
        int dateFmt = clamp(WidgetPrefs.i(c,id,"dateFormat",0),0,WidgetPrefs.DATE_PATTERNS.length-1);

        for (int i=0;i<TIME_IDS.length;i++) {
            int v=TIME_IDS[i];
            rv.setViewVisibility(v, i==tf ? View.VISIBLE : View.GONE);
            rv.setTextViewTextSize(v, TypedValue.COMPLEX_UNIT_SP, timeSize);
            rv.setTextColor(v,timeColor);
            rv.setInt(v,"setGravity",gravity);
            String f12 = hour==1 ? "HH:mm" : "h:mm";
            String f24 = hour==2 ? "h:mm" : "HH:mm";
            rv.setCharSequence(v,"setFormat12Hour",f12);
            rv.setCharSequence(v,"setFormat24Hour",f24);
            translate(c,rv,v,WidgetPrefs.i(c,id,"timeX",0),WidgetPrefs.i(c,id,"timeY",0));
        }
        for (int i=0;i<DATE_IDS.length;i++) {
            int v=DATE_IDS[i];
            rv.setViewVisibility(v, showDate && i==df ? View.VISIBLE : View.GONE);
            rv.setTextViewTextSize(v, TypedValue.COMPLEX_UNIT_SP, dateSize);
            rv.setTextColor(v,dateColor);
            rv.setInt(v,"setGravity",gravity);
            String pattern=WidgetPrefs.DATE_PATTERNS[dateFmt];
            rv.setCharSequence(v,"setFormat12Hour",pattern);
            rv.setCharSequence(v,"setFormat24Hour",pattern);
            translate(c,rv,v,WidgetPrefs.i(c,id,"dateX",0),WidgetPrefs.i(c,id,"dateY",0));
        }

        int pad = dp(c, compact ? 10 : 18);
        rv.setViewPadding(R.id.root,pad,pad,pad,pad);

        Intent edit = new Intent(c,WidgetConfigActivity.class);
        edit.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);
        PendingIntent pi = PendingIntent.getActivity(c,id,edit,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.root,pi);
        mgr.updateAppWidget(id,rv);
    }

    private static void translate(Context c, RemoteViews rv, int id, int xDp, int yDp) {
        rv.setFloat(id,"setTranslationX",dpFloat(c,xDp));
        rv.setFloat(id,"setTranslationY",dpFloat(c,yDp));
    }
    private static int gravity(int i) { return i==0 ? Gravity.START : (i==2 ? Gravity.END : Gravity.CENTER_HORIZONTAL); }
    private static int parseColor(String s,int def) { try { return Color.parseColor(s); } catch(Exception e){ return def; } }
    private static int clamp(int v,int a,int b){ return Math.max(a,Math.min(b,v)); }
    private static int dp(Context c,int d){ return Math.round(dpFloat(c,d)); }
    private static float dpFloat(Context c,int d){ return d*c.getResources().getDisplayMetrics().density; }
}

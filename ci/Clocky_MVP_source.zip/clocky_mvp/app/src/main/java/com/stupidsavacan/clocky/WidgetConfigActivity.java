package com.stupidsavacan.clocky;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.util.Locale;

public class WidgetConfigActivity extends Activity {
    private int appWidgetId;
    private TextClock previewTime, previewDate;
    private Spinner timeFont,dateFont,align,bg,hour,dateFormat;
    private SeekBar timeSize,dateSize,timeX,timeY,dateX,dateY;
    private CheckBox showDate;
    private EditText timeColor,dateColor;
    private TextView timeSizeValue,dateSizeValue,timePosValue,datePosValue;
    private LinearLayout previewBox;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        appWidgetId=getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,AppWidgetManager.INVALID_APPWIDGET_ID);
        if(appWidgetId!=AppWidgetManager.INVALID_APPWIDGET_ID){
            Intent r=new Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,appWidgetId);
            setResult(RESULT_CANCELED,r);
        }
        buildUi();
        load();
        refresh();
    }

    private void buildUi(){
        ScrollView scroll=new ScrollView(this);
        LinearLayout page=col();
        page.setPadding(dp(18),dp(14),dp(18),dp(28));
        scroll.addView(page);

        TextView title=label("Clocky",28); title.setTypeface(Typeface.DEFAULT_BOLD); page.addView(title);
        TextView sub=label(appWidgetId==AppWidgetManager.INVALID_APPWIDGET_ID ?
                "プレビュー。実際の設定はホーム画面からClockyを追加して行います。" :
                "時計と日付を独立してカスタマイズ",14);
        sub.setTextColor(0xff666666); page.addView(sub);

        previewBox=col();
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(230));
        pp.setMargins(0,dp(16),0,dp(16));
        previewBox.setLayoutParams(pp); previewBox.setGravity(Gravity.CENTER); previewBox.setPadding(dp(14),dp(12),dp(14),dp(12));
        previewDate=new TextClock(this); previewDate.setIncludeFontPadding(false); previewDate.setGravity(Gravity.CENTER);
        previewTime=new TextClock(this); previewTime.setIncludeFontPadding(false); previewTime.setGravity(Gravity.CENTER);
        previewBox.addView(previewDate,new LinearLayout.LayoutParams(-1,-2));
        previewBox.addView(previewTime,new LinearLayout.LayoutParams(-1,-2));
        page.addView(previewBox);

        page.addView(section("TIME"));
        timeFont=spinner(new String[]{"Modern / Light","Rounded","Serif","Condensed","Mono"}); addRow(page,"フォント",timeFont);
        timeSize=seek(48,200); timeSizeValue=label("",13); page.addView(control("時計サイズ",timeSize,timeSizeValue));
        timeX=seek(-40,40); timeY=seek(-40,40); timePosValue=label("",13);
        page.addView(control("X位置",timeX,null)); page.addView(control("Y位置",timeY,timePosValue));
        hour=spinner(new String[]{"端末設定に従う","24時間","12時間"}); addRow(page,"時刻形式",hour);
        timeColor=text("#FFFFFFFF"); addRow(page,"時刻色 (#AARRGGBB)",timeColor);

        page.addView(section("DATE"));
        showDate=new CheckBox(this); showDate.setText("日付を表示"); page.addView(showDate);
        dateFont=spinner(new String[]{"Modern / Light","Rounded","Serif","Condensed","Mono"}); addRow(page,"フォント",dateFont);
        dateSize=seek(10,40); dateSizeValue=label("",13); page.addView(control("日付サイズ",dateSize,dateSizeValue));
        dateX=seek(-40,40); dateY=seek(-40,40); datePosValue=label("",13);
        page.addView(control("X位置",dateX,null)); page.addView(control("Y位置",dateY,datePosValue));
        dateFormat=spinner(new String[]{"8月14日(金)","FRI, AUG 14","2026.08.14","FRI 14 AUG"}); addRow(page,"形式",dateFormat);
        dateColor=text("#CCFFFFFF"); addRow(page,"日付色 (#AARRGGBB)",dateColor);

        page.addView(section("LAYOUT"));
        align=spinner(new String[]{"左","中央","右"}); addRow(page,"揃え",align);
        bg=spinner(new String[]{"透明","Dark","Light"}); addRow(page,"背景",bg);

        Button apply=new Button(this);
        apply.setText(appWidgetId==AppWidgetManager.INVALID_APPWIDGET_ID ? "ホーム画面からウィジェットを追加" : "保存して反映");
        apply.setOnClickListener(v->apply());
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.setMargins(0,dp(20),0,0);
        page.addView(apply,bp);
        setContentView(scroll);

        hook(timeFont); hook(dateFont); hook(align); hook(bg); hook(hour); hook(dateFormat);
        hook(timeSize); hook(dateSize); hook(timeX); hook(timeY); hook(dateX); hook(dateY);
        showDate.setOnCheckedChangeListener((v,x)->refresh());
        TextWatcher tw=new TextWatcher(){ public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){refresh();} public void afterTextChanged(Editable e){} };
        timeColor.addTextChangedListener(tw); dateColor.addTextChangedListener(tw);
    }

    private void load(){
        if(appWidgetId==AppWidgetManager.INVALID_APPWIDGET_ID){
            timeFont.setSelection(0); dateFont.setSelection(0); align.setSelection(1); bg.setSelection(0); hour.setSelection(0); dateFormat.setSelection(0);
            set(timeSize,120,48); set(dateSize,18,10); set(timeX,0,-40); set(timeY,0,-40); set(dateX,0,-40); set(dateY,0,-40); showDate.setChecked(true); return;
        }
        timeFont.setSelection(WidgetPrefs.i(this,appWidgetId,"timeFont",0));
        dateFont.setSelection(WidgetPrefs.i(this,appWidgetId,"dateFont",0));
        align.setSelection(WidgetPrefs.i(this,appWidgetId,"align",1)); bg.setSelection(WidgetPrefs.i(this,appWidgetId,"bg",0));
        hour.setSelection(WidgetPrefs.i(this,appWidgetId,"hourMode",0)); dateFormat.setSelection(WidgetPrefs.i(this,appWidgetId,"dateFormat",0));
        set(timeSize,WidgetPrefs.i(this,appWidgetId,"timeSize",120),48); set(dateSize,WidgetPrefs.i(this,appWidgetId,"dateSize",18),10);
        set(timeX,WidgetPrefs.i(this,appWidgetId,"timeX",0),-40); set(timeY,WidgetPrefs.i(this,appWidgetId,"timeY",0),-40);
        set(dateX,WidgetPrefs.i(this,appWidgetId,"dateX",0),-40); set(dateY,WidgetPrefs.i(this,appWidgetId,"dateY",0),-40);
        showDate.setChecked(WidgetPrefs.b(this,appWidgetId,"showDate",true));
        timeColor.setText(WidgetPrefs.s(this,appWidgetId,"timeColor","#FFFFFFFF"));
        dateColor.setText(WidgetPrefs.s(this,appWidgetId,"dateColor","#CCFFFFFF"));
    }

    private void apply(){
        if(appWidgetId==AppWidgetManager.INVALID_APPWIDGET_ID){ Toast.makeText(this,"ホーム画面を長押し → ウィジェット → Clocky を追加してください",Toast.LENGTH_LONG).show(); return; }
        WidgetPrefs.save(this,appWidgetId,timeFont.getSelectedItemPosition(),dateFont.getSelectedItemPosition(),
                val(timeSize,48),val(dateSize,10),val(timeX,-40),val(timeY,-40),val(dateX,-40),val(dateY,-40),
                align.getSelectedItemPosition(),bg.getSelectedItemPosition(),hour.getSelectedItemPosition(),dateFormat.getSelectedItemPosition(),
                showDate.isChecked(),timeColor.getText().toString(),dateColor.getText().toString());
        ClockWidgetProvider.update(this,appWidgetId);
        setResult(RESULT_OK,new Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,appWidgetId));
        finish();
    }

    private void refresh(){
        if(previewTime==null)return;
        int tf=timeFont.getSelectedItemPosition(), df=dateFont.getSelectedItemPosition();
        previewTime.setTypeface(Typeface.create(WidgetPrefs.FONTS[Math.max(0,tf)],Typeface.NORMAL));
        previewDate.setTypeface(Typeface.create(WidgetPrefs.FONTS[Math.max(0,df)],Typeface.NORMAL));
        previewTime.setTextSize(val(timeSize,48)); previewDate.setTextSize(val(dateSize,10));
        previewDate.setVisibility(showDate.isChecked()?View.VISIBLE:View.GONE);
        int g=align.getSelectedItemPosition()==0?Gravity.START:(align.getSelectedItemPosition()==2?Gravity.END:Gravity.CENTER_HORIZONTAL);
        previewTime.setGravity(g); previewDate.setGravity(g);
        previewTime.setTranslationX(dpF(val(timeX,-40))); previewTime.setTranslationY(dpF(val(timeY,-40)));
        previewDate.setTranslationX(dpF(val(dateX,-40))); previewDate.setTranslationY(dpF(val(dateY,-40)));
        previewTime.setTextColor(color(timeColor.getText().toString(),Color.WHITE)); previewDate.setTextColor(color(dateColor.getText().toString(),0xccffffff));
        String p=WidgetPrefs.DATE_PATTERNS[Math.max(0,dateFormat.getSelectedItemPosition())]; previewDate.setFormat12Hour(p); previewDate.setFormat24Hour(p);
        int hm=hour.getSelectedItemPosition(); previewTime.setFormat12Hour(hm==1?"HH:mm":"h:mm"); previewTime.setFormat24Hour(hm==2?"h:mm":"HH:mm");
        previewBox.setBackgroundColor(bg.getSelectedItemPosition()==1?0xee111111:(bg.getSelectedItemPosition()==2?0xeeffffff:0x22000000));
        timeSizeValue.setText(val(timeSize,48)+"sp"); dateSizeValue.setText(val(dateSize,10)+"sp");
        timePosValue.setText("X "+val(timeX,-40)+" / Y "+val(timeY,-40)+" dp"); datePosValue.setText("X "+val(dateX,-40)+" / Y "+val(dateY,-40)+" dp");
    }

    private LinearLayout col(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private TextView label(String s,float sp){ TextView v=new TextView(this); v.setText(s); v.setTextSize(sp); v.setPadding(0,dp(4),0,dp(4)); return v; }
    private TextView section(String s){ TextView v=label(s,13); v.setTypeface(Typeface.DEFAULT_BOLD); v.setTextColor(0xff666666); v.setPadding(0,dp(18),0,dp(6)); return v; }
    private Spinner spinner(String[] a){ Spinner s=new Spinner(this); s.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,a)); return s; }
    private EditText text(String s){ EditText e=new EditText(this); e.setSingleLine(true); e.setText(s); return e; }
    private SeekBar seek(int min,int max){ SeekBar s=new SeekBar(this); s.setMax(max-min); return s; }
    private View control(String name,SeekBar s,TextView value){ LinearLayout l=col(); LinearLayout h=new LinearLayout(this); h.setGravity(Gravity.CENTER_VERTICAL); TextView n=label(name,14); h.addView(n,new LinearLayout.LayoutParams(0,-2,1)); if(value!=null)h.addView(value); l.addView(h); l.addView(s); return l; }
    private void addRow(LinearLayout p,String name,View v){ p.addView(label(name,13)); p.addView(v,new LinearLayout.LayoutParams(-1,-2)); }
    private void hook(Spinner s){ s.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?>p,View v,int x,long id){refresh();} public void onNothingSelected(AdapterView<?>p){}}); }
    private void hook(SeekBar s){ s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){refresh();} public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}}); }
    private void set(SeekBar s,int value,int min){ s.setProgress(value-min); }
    private int val(SeekBar s,int min){ return s.getProgress()+min; }
    private int color(String s,int d){ try{return Color.parseColor(s);}catch(Exception e){return d;} }
    private int dp(int v){return Math.round(dpF(v));} private float dpF(int v){return v*getResources().getDisplayMetrics().density;}
}

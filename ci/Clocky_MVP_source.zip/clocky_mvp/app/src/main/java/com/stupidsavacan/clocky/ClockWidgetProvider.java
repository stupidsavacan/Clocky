package com.stupidsavacan.clocky;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.os.Bundle;

public class ClockWidgetProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id: ids) ClockWidgetRenderer.render(c,m,id);
    }
    @Override public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle opts) {
        ClockWidgetRenderer.render(c,m,id);
    }
    @Override public void onDeleted(Context c, int[] ids) {
        for (int id: ids) WidgetPrefs.delete(c,id);
    }
    static void update(Context c,int id) {
        ClockWidgetRenderer.render(c,AppWidgetManager.getInstance(c),id);
    }
}

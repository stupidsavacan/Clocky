package com.stupidsavacan.clocky;

import android.content.Context;
import android.content.SharedPreferences;

final class WidgetPrefs {
    private static final String FILE = "clocky_widgets";
    static final String[] FONTS = {"sans-serif-light", "sans-serif-rounded", "serif", "sans-serif-condensed", "monospace"};
    static final String[] DATE_PATTERNS = {"M月d日(E)", "EEE, MMM d", "yyyy.MM.dd", "EEE d MMM"};

    private WidgetPrefs() {}

    static SharedPreferences p(Context c) { return c.getSharedPreferences(FILE, Context.MODE_PRIVATE); }
    private static String k(int id, String key) { return "w_" + id + "_" + key; }

    static int i(Context c, int id, String key, int def) { return p(c).getInt(k(id,key), def); }
    static boolean b(Context c, int id, String key, boolean def) { return p(c).getBoolean(k(id,key), def); }
    static String s(Context c, int id, String key, String def) { return p(c).getString(k(id,key), def); }

    static void save(Context c, int id, int timeFont, int dateFont, int timeSize, int dateSize,
                     int timeX, int timeY, int dateX, int dateY, int align, int bg, int hourMode,
                     int dateFormat, boolean showDate, String timeColor, String dateColor) {
        p(c).edit()
            .putInt(k(id,"timeFont"),timeFont).putInt(k(id,"dateFont"),dateFont)
            .putInt(k(id,"timeSize"),timeSize).putInt(k(id,"dateSize"),dateSize)
            .putInt(k(id,"timeX"),timeX).putInt(k(id,"timeY"),timeY)
            .putInt(k(id,"dateX"),dateX).putInt(k(id,"dateY"),dateY)
            .putInt(k(id,"align"),align).putInt(k(id,"bg"),bg).putInt(k(id,"hourMode"),hourMode)
            .putInt(k(id,"dateFormat"),dateFormat).putBoolean(k(id,"showDate"),showDate)
            .putString(k(id,"timeColor"),timeColor).putString(k(id,"dateColor"),dateColor)
            .apply();
    }

    static void delete(Context c, int id) {
        SharedPreferences sp = p(c);
        SharedPreferences.Editor e = sp.edit();
        for (String key : sp.getAll().keySet()) if (key.startsWith("w_" + id + "_")) e.remove(key);
        e.apply();
    }
}
